package com.sentimentAnalysis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentimentAnalysisRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SentimentAnalysisRestApiApplication.class, args);
	}

}

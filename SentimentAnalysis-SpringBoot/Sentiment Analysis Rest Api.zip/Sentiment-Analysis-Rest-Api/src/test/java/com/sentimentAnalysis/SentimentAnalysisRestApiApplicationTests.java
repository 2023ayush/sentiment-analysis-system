package com.sentimentAnalysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SentimentAnalysisRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
